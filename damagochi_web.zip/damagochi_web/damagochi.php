<?php
require_once "config.php";
require 'vendor/autoload.php';

use Aws\S3\S3Client;
use Aws\Exception\AwsException;

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = '99'; // 테스트용
}
$player_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT gold FROM gamedatas WHERE id = ?");
$stmt->bind_param("i", $player_id);
$stmt->execute();
$result = $stmt->get_result();
$game_data = $result->fetch_assoc();

$log = "";
$action = "게임 시작";
$action_code = 0;

if(!$game_data){
    
}
else{
    $gold = $game_data['gold'];
}

// 버튼 처리
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    if (isset($_POST["feed"])) {
        $log = "당신은 동물에게 먹이를 주었습니다!";
        $action = "feed";
        $action_code = 1;
    }

    if (isset($_POST["play"])) {
        $log = "당신은 동물과 놀았습니다!";
        $action = "play";
        $action_code = 2;
    }

    if (isset($_POST["clean"])) {
        $log = "당신은 동물을 깨끗하게 씻겼습니다!";
        $action = "clean";
        $action_code = 3;
    }

    if (isset($_POST["buy_item"])) {
        if ($gold >= 300) {
            $gold -= 300;
            $log = "상점에서 아이템(300G)을 구매했습니다!";
            $action = "buy_item_-300";
            $action_code = 4;
        } else {
            $log = "골드가 부족합니다!";
            $action = "buy_item_fail";
            $action_code = 5;
        }
    }

    if (isset($_POST["gold100"])) {
        $gold += 100;
        $log = "100 골드를 획득했습니다!";
        $action = "gold_+100";
        $action_code = 6;
    }

    //DB 처리
    $stmt = $conn1->prepare("UPDATE gamedatas SET gold = ?, last_action = ? WHERE id = ?");
    $stmt->bind_param("isi", $gold, $action, $player_id);
    $stmt->execute();

    $csvFile = tempnam(sys_get_temp_dir(), 'gamedata_') . '.csv';
    $fp = fopen($csvFile, 'w');
    fputcsv($fp, array_keys($game_data)); // 헤더
    fputcsv($fp, $game_data);            // 데이터
    fclose($fp);

    $s3 = new S3Client([
        'version' => 'latest',
        'region'  => getenv('AWS_DEFAULT_REGION'),
    ]);

    $bucket = 'suhk-rds-export-bucket';
    $key = "exports/player_{$player_id}_" . date('Ymd_His') . ".csv";
    
    try {
        $s3->putObject([
            'Bucket' => $bucket,
            'Key'    => $key,
            'SourceFile' => $csvFile,
            'ACL'    => 'private'
            'Metadata' => [
                'action_code' => (string)$action_code  // int → string으로 변환
                'player_id' => (string)$player_id
            ]
        ]);
        $log .= " ✅ CSV가 S3에 업로드되었습니다: {$key}";
    } catch (AwsException $e) {
        $log .= " ❌ S3 업로드 실패: " . $e->getMessage();
    }

    // 임시 파일 삭제
    unlink($csvFile);
}
?>

<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>PHP 다마고치 게임</title>
<style>
    body { font-family: Arial; text-align: center; background: #f5f5f5; }
    .pet {
        width: 200px; height: 200px;
        background: #87CEFA;
        margin: 20px auto;
        border: 3px solid #333;
        border-radius: 10px;
    }
    .buttons button {
        margin: 8px;
        padding: 10px 20px;
        font-size: 16px;
        border-radius: 8px;
        border: none;
        cursor: pointer;
    }
    .log {
        margin-top: 20px;
        padding: 15px;
        width: 60%;
        margin-left: auto;
        margin-right: auto;
        background: #fff;
        border: 2px solid #333;
        border-radius: 8px;
        font-size: 18px;
    }
    .gold {
        font-size: 22px;
        font-weight: bold;
        margin-top: 15px;
        color: #444;
    }
    .shop {
        margin-top: 25px;
        padding: 15px;
        background: #e3ffe3;
        border: 2px solid #5a9d5a;
        width: 60%;
        margin-left: auto;
        margin-right: auto;
        border-radius: 8px;
    }
</style>
</head>
<body>

<h1>🐾 PHP 다마고치 게임</h1>

<div class="pet"></div>
<p>현재 동물 (사각형 이미지)</p>

<div class="gold">💰 골드: <?= $gold ?> G</div>

<form method="POST">
    <div class="buttons">
        <button name="feed" style="background:#ffcccb;">먹이주기</button>
        <button name="play" style="background:#c1ffc1;">놀아주기</button>
        <button name="clean" style="background:#cce5ff;">씻기기</button>
        <button name="gold100" style="background:#fff2a8;">+100 골드 얻기</button>
    </div>

    <div class="shop">
        <h2>🏪 상점</h2>
        <p>아이템 가격: 300골드</p>
        <button name="buy_item" style="background:#ffd9a8;">아이템 구매</button>
    </div>
</form>

<div class="log">
    <?= $log ?> <?= $action ?>
</div>

</body>
</html>
